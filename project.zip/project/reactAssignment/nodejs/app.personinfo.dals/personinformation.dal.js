var mongoose = require("mongoose");
    //autoIncrement = require("mongoose-auto-increment");
var personmod = require("./../app.personinfo.models/person.model");
var personInfoModel = mongoose.model("PersonInfo");
var tempPersonInfoModel = mongoose.model("TempPersonInfo");
    //connection = require("./../userinfowebserver");

//autoIncrement.initialize(connection);

module.exports={

    getPersonInfo:function(request, response){

        personInfoModel.find().exec(function(err,res){
            if(err){
                response.status = 500;
                response.send({status:response.status, error:err});
            }
            response.send({status:200, data:res});
        });
    },

    postPersonalInfo:function(request, response){
        var userRole = request.body.userrole;   //get userrole admin/operator

        var personInfo = {
            //personId:request.body.personId,
            fullName :{
                firstName: request.body.fullName.firstName,
                middleName: request.body.fullName.middleName,
                lastName: request.body.fullName.lastName
            },
            gender: request.body.gender,
            dateOfBirth: request.body.dateOfBirth,
            age:  request.body.age, 
            address: {
                flatNumber: request.body.address.flatNumber,
                societyName: request.body.address.societyName,
                areaName: request.body.address.areaName
            },
            email: request.body.email,
            city: request.body.city,
            state: request.body.state,
            pinCode: request.body.pinCode,
            phoneNo: request.body.phoneNo,                 
            mobileNo:request.body.mobileNo,
            physicalDisability:request.body.physicalDisability,                 
            maritalStatus:request.body.maritalStatus,
            education: request.body.education,
            birthSign:request.body.birthSign,                       
            isAuthorized: request.body.isAuthorized  
        }

        console.log(personInfo);

        if(userRole=="admin"){   //check userrole, if it is admin then save info in PersonalInfo 
            //table else save in temp table.
            //personInfoModel.plugin(autoIncrement.plugin, {model: 'personInfo', field: 'personId'});

            personInfoModel.create(personInfo, function(err,res){
                    if(err){
                        respose.status = 500;
                        response.send({status:respose.status, error:err});
                    }
                    response.send({status:200, Message:"Person Information Added Successfully"});
                });
        }
        else{
            tempPersonInfoModel.create(personInfo, function(err,res){
                    if(err){
                        respose.status = 500;
                        response.send({status:respose.status, error:err});
                    }
                    response.send({status:200, Message:"Person Information Added Successfully. Approve will soon."});
                });
        }
          
    },


    putPersonInfo:function(request, response){
        var personInfo = {
            personId:request.body.personId,
            fullName :{
                firstName: request.body.fullName.firstName,
                middleName: request.body.fullName.middleName,
                lastName: request.body.fullName.lastName
            },
            gender: request.body.gender,
            dateOfBirth: request.body.dateOfBirth,
            age:  request.body.age, 
            address: {
                flatNumber: request.body.address.flatNumber,
                societyName: request.body.address.societyName,
                areaName: request.body.address.areaName
            },
            email: request.body.email,
            city: request.body.city,
            state: request.body.state,
            pinCode: request.body.pinCode,
            phoneNo: request.body.phoneNo,                 
            mobileNo:request.body.mobileNo,
            physicalDisability:request.body.physicalDisability,                 
            maritalStatus:request.body.maritalStatus,
            education: request.body.education,
            birthSign:request.body.birthSign,                       
            isAuthorized: request.body.isAuthorized  
        }

        tempPersonInfoModel.create(personInfo, function(err,res){
            if(err){
                respose.status = 500;
                response.send({status:respose.status, error:err});
            }
            response.send({status:200, Message:"Personal Information Updated Successfully. Approve will soon."});
        });
           
    },
}