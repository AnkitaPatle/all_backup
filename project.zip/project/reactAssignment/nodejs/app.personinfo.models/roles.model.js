var mongoose = require("mongoose");

var rolesSchema = mongoose.Schema({
    RoleID: Number,
    RoleName: String
  });
  
module.exports = mongoose.model("Roles", rolesSchema, "Roles");