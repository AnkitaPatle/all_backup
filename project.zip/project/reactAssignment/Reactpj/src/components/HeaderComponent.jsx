import React, {Component} from 'react';

class HeaderComponent extends Component {
    render() { 
        return ( 
            <nav className="navbar navbar-default">
                <div className="container-fluid">
                    <ul className="nav navbar-nav">
                        <li ><a href="/home">Dashboard</a></li>
                        <li><a href="/role">Roles</a></li>
                        <li><a href="/users">Users</a></li>
                        <li><a href="/personlist">Persons-List</a></li>
                    </ul>
                    <ul className="nav navbar-nav1 logout-div">
                        <li><a href="/logout">Logout</a></li>
                    </ul>
                </div>
            </nav>
         );
    }
}
 
export default HeaderComponent;