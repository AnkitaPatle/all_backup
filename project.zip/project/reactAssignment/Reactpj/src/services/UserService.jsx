class UserService{

    getUsers(token){
        let promise = fetch("http://localhost:4040/api/users",{
                                method:"GET",
                                headers:{
                                    "Authorization":"bearer "+token
                                },
                            });
        return promise;
    }
}

export default UserService;