var express = require("express");
var cors = require("cors");
var bodyPaser = require("body-parser");
var app = express();
var mongoose = require("mongoose");
var port = process.env.PORT || 5000

app.use(bodyPaser.json());
app.use(cors());
app.use(bodyPaser.urlencoded({extended:false}));

const mongoURL = "mongodb://localhost:27017/merndb";

mongoose
.connect(mongoURL, {useNewUrlParser: true})
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err))

var Users = require('./routes/Users');

app.use('/users', Users);

app.listen(port, () => {
    console.log("Server is Running: " + port);
});
