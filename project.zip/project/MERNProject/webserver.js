// 1. Load require packages
var express = require("express");
var instance = express();
var router = express.Router();
var bodyPaser = require("body-parser");
var cors = require("cors");
var jwt = require("jsonwebtoken");

var mongoose = require("mongoose");
mongoose.Promise = global.Promise;

// 2. configure middleware
instance.use(router);
instance.use(bodyPaser.urlencoded({extended:false}));
instance.use(bodyPaser.json());
instance.use(cors());

// 3. connect to MongoDB
mongoose.connect("mongodb://localhost/merndb",{useNewUrlParser: true});

var dbConnect = mongoose.connection;
if(!dbConnect){
    console.log("Sorry Connection is not established");
    return;    
}

/* Code for the User management */
// 4. Users Schema  
var userSchema = mongoose.Schema({
    UserId: String,
    UserName: String,
    Email: String,
    Password: String,
    Role: String
});

var userModel = mongoose.model("users", userSchema, "users");

/* Code for Create/Register user */
// 5. Create a new user
instance.post("/api/user/create", (request, response) => {
    var user = {
        UserId: request.body.UserId,
        UserName: request.body.UserName,
        Email: request.body.Email,
        Password: request.body.Password,
        Role: request.body.Role
    };

    userModel.create(user,(err, res) => {
        if(err){
            console.log("in if");
            
            response.statusCode = 500;
            response.send({statusCode:response.statusCode, message:err});
        }
        console.log("out of if");
        
        response.send({statusCode: 200, message:res});
    });
});

/* Login User and Generate Token */
// 6. The Secret for JWT
var jwtSettings = {
    jwtScrete: "dbcsbiobc0708hdfcyesbombob"
};

// Set the secret with express object
instance.set("jwtScrete", jwtSettings.jwtScrete);
var tokenStore = "";

// 7. authenticate User
instance.post("/api/users/auth", (request, response) => {
    var user = {
        UserId: request.body.UserId,
        Password: request.body.Password
    };
    console.log("In Auth User: " +JSON.stringify(user));
    userModel.findOne({UserId: request.body.UserId}, (err, usr) => {
        if(err){
            console.log("Some error occured");
            throw error;
        }
        // 7a. If user not found the respond error
        if(!usr){
            response.send({statusCode: 404, message: "Sorry!! user is not available"});

        }else if(usr){ 
            // 7b. User is available but password not match, the respond error
            console.log("In else if: " +JSON.stringify(usr));
            if(usr.Password != user.Password){
                response.send({statusCode:404, message:"Sorry!! UserId and Password does not match"});

            }else{
                // 7c. sign-In the user and generate token
                var token = jwt.sign({usr}, instance.get("jwtScrete"), {
                    expiresIn:3600
                });
                // Save token globally
                tokenStore = token;
                response.send({authenticated: true, message: "Login Success", token: token});
            } 
        }
    });
});

/* The Code for Product API */
var productSchecma = mongoose.Schema({
    ProductID: Number,
    ProductName: String,
    CategoryName: String,
    Manufacturer: String,
    Price: Number
});

var productModel = mongoose.model("Products", productSchecma, "Products");
// 8. varify the token and provide access 
// get products
instance.get("/api/products", (request, response) => {
    // 8a. read request headers, header contains bearer<space><token>
    var tokenReceived = request.headers.authorization.split(" ")[1];
    // 8b. varify the token
    jwt.verify(tokenReceived, instance.get("jwtScrete"), (err, decoded) => {
        console.log("In varify");
        if(err){
            console.log("In auth error");
            response.send({success: false, message: "Token verification failed"});            
        }else{
            console.log("In auth success");
            // 8c. decode the request
            request.decoded = decoded;
            productModel.find().exec((err,res) => {
                if(err){
                    response.statusCode = 500;
                    response.send({status: response.statusCode, error: err});
                }
                response.send({status: 200, data: res});
            });            
        }        
    });
});

// post products
instance.post("/api/products", (request, response) => {
    // parsing posted data into JSON
    var prd = {
        ProductID: request.body.ProductID,
        ProductName: request.body.ProductName,
        CategoryName: request.body.CategoryName,
        Manufacturer: request.body.Manufacturer,
        Price: request.body.Price
    };
    productModel.create(prd, (err, res) => {
        if(err){
            response.statusCode = 500;
            response.send(err);
        }
        response.send({status:200, data: res});
    });
});

instance.get("/api/products/:id", function(request, response) {}); 

instance.put("/api/products/:id", function(request, response) {});

instance.delete("/api/products/:id", function(request, response) {}); 

// 9. start listening 

instance.listen(4070, function() { 
    console.log("started listening on port 4070");
});
