import React, { Component } from 'react';
import './css/Dashboard.css';


class Dashboard extends Component {
    

    // onClickNewUser = () =>{
    //     const h = this.props.history;
    //     h.push('/newuser');
    // }

    render() { 
        return (  
            
          // <div className="container">
          //   <nav className="navbar navbar-expand-sm bg-dark">  
          //     <ul className="navbar-nav">
          //         <li className="nav-item"><a className="nav-link" href="#">Home</a></li>
          //         <li className="nav-item"><a className="nav-link" href="#">Add new user</a></li>
          //         <li className="nav-item"><a className="nav-link" href="#">User List</a></li>
          //         <li className="nav-item"><a className="nav-link" href="#">Logout</a></li>
          //     </ul>
          //   </nav>   
          //   </div>        


            // <nav className= "navbar navbar-default">
            // <div className = "container">
            // <div className="navbar-header">
            //     <ul className = "nav navbar-nav">
            //         <li><a href="#home">Home</a></li>
            //         <li><a href="#home">UserList</a></li>
            //         <li><a href="#home">Add New User</a></li>
            //     </ul>
            //     </div>
            //     <div className="topnav-right">
            //     <a href="#">Logout</a>
            // </div> 
            // </div>           
            // </nav>

            
            // <div className="topnav">
            //     <a className="" href="#home">Home</a>
            //     <a className="" href="#home">User List</a>
            //     <a className="" href="#home">Add Operator</a>
                
            //     <div className="topnav-right">
            //     <a href="#">Logout</a>
            // </div>
            // </div>
            <div></div>
            

        
         );
    }
}

 
export default Dashboard;