import axios from 'axios';

export const register = newUser => {
    return axios.post('users/register', {
        UserId: newUser.UserId,
        UserName: newUser.UserName,
        Email: newUser.Email,
        Password: newUser.Password,
        Role: newUser.Role
    })
    .then(res => {
        console.log("Registered");
    })
}

export const login = user => {
    return axios.post('users/login', {
        Email: user.Email,
        Password: user.Password
    })
    .then(res => {
        localStorage.setItem('usertoken', res.data)
        return res.data
    })
    .catch(err => {
        console.log(err);
    })
}