import React, { Component } from 'react';
import jwt_decode from 'jwt-decode';

class UserList extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            UserId : "",
            UserName: "",
            Email: "",
            Role: ""
        }
    }

    componentDidMount(){
        const token = localStorage.usertoken
        const decoded = jwt_decode(token)
        this.setState({
            UserId: decoded.UserId,
            UserName: decoded.UserName,
            Email: decoded.Email,
            Role: decoded.Role
        });
        
    }
    render() { 
        return ( 
            <div className="container">
            <table id="dtBasicExample" className="table table-striped table-bordered table-sm" cellSpacing="0" width="100%">
                <thead className = "table-info">
                <tr>
                <th className="th-sm">UserId</th>
                <th className="th-sm">User Name</th>
                <th className="th-sm">Email Address</th>
                <th className="th-sm">Role</th>
                </tr>
                </thead>
                <tbody className = "table-info">
                    <tr>                        
                        <td className="th-sm">{this.state.UserId}</td>
                        <td className="th-sm">{this.state.UserName}</td>
                        <td className="th-sm">{this.state.Email}</td>
                        <td className="th-sm">{this.state.Role}</td>     
                    </tr>
                </tbody>
            </table>              
        </div>            
            
         );
    }

}

export default UserList;