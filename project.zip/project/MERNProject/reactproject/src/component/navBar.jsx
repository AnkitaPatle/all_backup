import React, { Component } from "react";
import { Link, withRouter } from "react-router-dom";

class NavBar extends Component {
  logOut(e) {
    e.preventDefault();
    localStorage.removeItem("usertoken");
    this.props.history.push("/");
  }
  render() {
    const userdata = (
      <ul className="navbar-nav">
        <li className="nav-item">
          <Link to="#" className="nav-link">
            Home
          </Link>
        </li>
        <li className="nav-item">
        <Link to="/newuser" className="nav-link">
            Add User
          </Link>
        </li>             
      </ul>
    );

    const userlist = (
        <ul className="navbar-nav">    
          <li className="nav-item">
          <Link to="/userlist" className="nav-link">
              User List
            </Link>
          </li>  
          <li className="nav-item">
          <a href="" onClick={this.logOut.bind(this)} className="nav-link">
              Logout
            </a>
          </li>  

        </ul>
      );
      return (
        <nav className="navbar navbar-expand-sm bg-dark">  
        <button 
        className="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbar1"
        aria-controls="navbar1"
        aria-expanded="false"
        aria-lable="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
        </button>
        
        <div className="collapse navbar-collapse" id="navbar1">
        <ul className="navbar-nav">
        <li className="nav-item">
          <Link to="/" className="nav-link">
            Login
          </Link>
        </li>
        </ul>
        {localStorage.usertoken ? userlist : userdata}
        </div>
        </nav>
      )
  }
}

export default withRouter(NavBar);
