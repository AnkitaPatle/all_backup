import React, { Component } from "react";
import "./css/login.css";
import { login } from "./userFunction.jsx";


class LoginPage extends Component {
    constructor(){
        super();
        this.state = {
            Email: "",
            Password: ""
        }
        this.onChange = this.onChange.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
    }

    onChange(e){
        this.setState({[e.target.name]: e.target.value});
    }

    onSubmit(e){
        e.preventDefault();

        const user = {
            Email: this.state.Email,
            Password: this.state.Password
        }
        login(user).then(res => {
            if(res){
                this.props.history.push('/userlist')
            }
        })
    }

  render() {
    return (
      <div id="login">
        <div className="container">
          <div
            id="login-row"
            className="row justify-content-center align-items-center" >
            <div id="login-column" className="col-md-6">
              <div id="login-box" className="col-md-12">
              <form noValidate onSubmit={this.onSubmit}>
                <h3 className="text-center text-info">Login</h3>

                <div className="form-group">
                  <label htmlFor="email" className="text-info">
                    Email Address:
                  </label>
                  <br />
                  <input
                    type="email"
                    name="email"
                    id="email"
                    className="form-control"
                    placeholder="Enter email"
                    value ={this.state.Email}
                    onChange={this.onChange}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="password" className="text-info">
                    Password:
                  </label>
                  <br />
                  <input
                    type="password"
                    name="password"
                    id="password"
                    className="form-control"
                    placeholder="Enter password"
                    value={this.state.Password}
                    onChange={this.onChange}
                  />
                </div>

                <div className="form-group">                  
                  <input
                    type="submit"
                    name="submit"
                    className="btn btn-info btn-md"
                    value="Login"
                    //onClick={this.onSubmit}
                  />
                </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default LoginPage;
