import React, { Component } from "react";
import "./css/login.css";
import { register } from "./userFunction";

class NewUser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      UserId: 0,
      UserName: "",
      Password: "",
      ConfirmPassword: "",
      Role: "",
      Roles: ["Admin", "Operator", "User"]
    };
    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }
  onChange(e) {
    this.setState({ [e.target.name]: e.target.value });
  }

  onSubmit(e) {
    e.preventDefault();

    const user = {
      UserId: this.state.UserId,
      UserName: this.state.UserName,
      Email: this.state.Email,
      Password: this.state.Password,
      Role: this.state.Role
    };
    register(user).then(res => {
      this.props.history.push("/login");
    });
  }

  render() {
    return (
      <div id="newuser">
        <div className="container">
          <div
            id="login-row"
            className="row justify-content-center align-items-center" >
            <div id="login-column" className="col-md-6">
              <div id="login-box" className="col-md-12">
              <form noValidate onSubmit={this.onSubmit}>
                <h3 className="text-center text-info">Add New User</h3>

                <div className="form-group">
                  <label htmlFor="username" className="text-info">
                    UserId:
                  </label>
                  <br />
                  <input
                    type="text"
                    name="username"
                    id="username"
                    className="form-control"
                    placeholder="Enter user id"
                    value ={this.state.UserId}
                    onChange={this.onChange}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="username" className="text-info">
                    Username:
                  </label>
                  <br />
                  <input
                    type="text"
                    name="username"
                    id="username"
                    className="form-control"
                    placeholder="Enter user Name"
                    value ={this.state.UserName}
                    onChange={this.onChange}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="email" className="text-info">
                    Email Address:
                  </label>
                  <br />
                  <input
                    type="email"
                    name="email"
                    id="email"
                    className="form-control"
                    placeholder="create Email"
                    value ={this.state.Email}
                    onChange={this.onChange}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="password" className="text-info">
                    Password:
                  </label>
                  <br />
                  <input
                    type="password"
                    name="password"
                    id="password"
                    className="form-control"
                    placeholder="create Password"
                    value ={this.state.Password}
                    onChange={this.onChange}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="password" className="text-info">
                    Role:
                  </label>
                  <br />
                  <select
                    className="form-control"
                    value={this.state.Role}
                    name="role"
                  ><option>Select Role</option>
                    {this.state.Roles.map((c, i) => (
                        <Options key={i} data={c} />
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <input
                    type="submit"
                    name="submit"
                    className="btn btn-info btn-md"
                    value="Add User"
                  />
                </div>
                </form>                
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

class Options extends Component {
  render() {
    return <option value={this.props.data}>{this.props.data}</option>;
  }
}

export default NewUser;
