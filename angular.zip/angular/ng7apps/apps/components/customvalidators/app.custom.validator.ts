import { AbstractControl } from "@angular/forms";

export class FormValidator {
  // 1. static method
  // 2. i/p parameter must be used carefully
  // 3. return type is "any"
  static checkVal(ctrl: AbstractControl): any {
    if (parseInt(ctrl.value) > 0) {
      return null; // valid
    } else {
      return { invalid: true }; // invalid
    }
  }

  static SelectRequiredvalidate(ctrl: AbstractControl): any{
   // console.log(ctrl);
    if(ctrl.value == " " || ctrl.value == "-1"){
 
     return {defaultselected :true};
    }else{
      return null;
    }
  }

  static TextBoxUppercaseValidator(ctrl: AbstractControl):any{
   /*  if(ctrl.value ===){

    } */
  }

}
