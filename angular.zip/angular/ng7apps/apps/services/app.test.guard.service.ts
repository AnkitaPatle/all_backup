import { Injectable } from '@angular/core';
import { Router,ActivatedRouteSnapshot, RouterStateSnapshot, CanActivate } from '@angular/router';
import { Http } from "@angular/http";

@Injectable()
export class AppGuardService implements CanActivate {
  url:string;
  constructor(private _router: Router, private http:Http) {
    this.url = "http://localhost:4070";
   
  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):boolean{ 

  console.log("CanActivate");

    alert("You are not allow to view this page, you will be redirect to ErrorComponent page");

    this._router.navigate(["error"]);

  return false;
      
  }
}

