import { Component, OnInit } from "@angular/core";
import { Category, Categories } from "./category.model";

@Component({
    selector: 'category-data',
    template:`
    <h2> Record are : {{_counter}}</h2>
    <table class="table table-striped table-bordered">
    <thead>
        <tr>
            <td>Category Id</td>
            <td>Category Name</td>
        </tr>
     </thead>
     <tbody>
         <tr *ngFor="let cat of categories"
         (click)="selectCategory(cat)">
             <td>{{cat.categoryId}}</td>
             <td>{{cat.categoryName}}</td>
         </tr>
     </tbody>
    </table> 
    <product-data [categoryName]='categoryName' (changedEmitter)="getChanged($event)"></product-data>   
    `
})
export class CategoryComponent implements OnInit{
    categories = Categories;
    categoryName:string;
    _counter:number = 0;

    constructor(){
        this.categoryName = "";
    }
    selectCategory(c:any){
        this.categoryName = c.categoryName
    }
   
    ngOnInit(){}

    getChanged(counter:number){
        console.log("In getChanged :"+this._counter)
        this._counter = counter;
    }
}