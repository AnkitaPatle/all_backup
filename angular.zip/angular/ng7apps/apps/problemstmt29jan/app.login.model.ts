export class Users{
    constructor(
        public UserId: string,
        public Password: string
    ){ }
}