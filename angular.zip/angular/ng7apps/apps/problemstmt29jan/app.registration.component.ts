import { Component, OnInit } from "@angular/core";

@Component({
    selector: "app-registration-component",
    template:`
    <h3>Registration Page</h3>
    <div class="container">

    <div class="form-group">
    Username
    <input type="text" class="form-control" name="userid" placeholder="Enter UserId"/>
    </div>

    <div class="form-group">
    Password
    <input type="password" class="form-control" name="password" placeholder="Enter Password"/>
    </div>

    <div class="form-group">
     Confirm Password
    <input type="password" class="form-control" name="cpassword" placeholder="Enter confirm Password"/>
    </div>
    
    <input type="reset" class="btn btn-primary" value="Cancel"/> &nbsp;
    <input type="submit" class="btn btn-primary" value="Register"/>

    </div>
    `
})
export class RegistrationComponent implements OnInit{
    constructor(){

    }
    ngOnInit():void{}
}