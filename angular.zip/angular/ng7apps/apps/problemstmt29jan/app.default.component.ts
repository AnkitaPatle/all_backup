import { Component, OnInit } from "@angular/core";

@Component({
    selector: "app-default-component",
    template: `
    <h3>Dashboard</h3>
    <div>{{message}}</div>    
    `
})
export class DefaultComponent implements OnInit{
    message: string;
    constructor(){
        this.message = 'Home Page';
    }
    ngOnInit(): void{

    }
}
