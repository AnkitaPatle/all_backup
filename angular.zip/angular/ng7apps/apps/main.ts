// 1. Angular Module file
import  {NgModule} from "@angular/core"
// 1. Import all standard modules
 import {BrowserModule} from "@angular/platform-browser"
 import {platformBrowserDynamic} from "@angular/platform-browser-dynamic"
 import {FormsModule, ReactiveFormsModule} from "@angular/forms"
 import { HttpModule } from "@angular/http";
// 2. Import all components and directives
import {SimpleComponent} from "./components/simplecomponent/app.simple.component"
import { ProductComponent } from "./components/productcomponent/app.product.component"
import { ProductFormComponent } from "./components/productformcomponent/app.productform.component";
import { SampleServiceComponent } from "./components/sampleservicecomponent/app.sample.service.component";
import { ProductServiceComponent } from "./components/productcomponent/app.productservice.component";
import { CategorySenderComponent } from "./componentscomm2b/app.categorysender.component";
import { ProductReceiverComponent } from "./componentscomm2b/app.productreceiver.component";
import { CategoryComponent } from "./componentscomm2a/Category.component";
import { ProductComponentC } from "./componentscomm2a/Product.component";

import { routing } from "./routecomponent/app.route.table";
import { HomeComponent } from "./routecomponent/app.home.component";
import { AboutComponent } from "./routecomponent/app.about.component";
import { ContactComponent } from "./routecomponent/app.contact.component";
import { ErrorComponent } from "./routecomponent/ErrorComponent";
import { MainComponent } from "./routecomponent/app.main.component";

//import { dashrouting } from "./problemstmt29jan/app.dashboard.route.table";
import { DefaultComponent } from "./problemstmt29jan/app.default.component";
import { LoginComponent } from "./problemstmt29jan/app.login.component";
import { RegistrationComponent } from "./problemstmt29jan/app.registration.component";
import { DashboardMainComponent } from "./problemstmt29jan/app.dashboard.main.component";

//import { from } from "rxjs";
// 3. Import all services

import { SampleService } from "./services/app.sample.service";
import { ProductService } from "./services/app.productservice";
import { CommunicationService } from "./componentscomm2b/app.communication.service";
import { AppGuardService } from "./services/app.test.guard.service";




@NgModule({

    imports:[BrowserModule, FormsModule, routing ,ReactiveFormsModule, HttpModule], //dashrouting
    declarations:[
        SimpleComponent,
        ProductComponent,
        ProductFormComponent,
        SampleServiceComponent, 
        ProductServiceComponent,
        CategorySenderComponent,
        ProductReceiverComponent,
        CategoryComponent,
        ProductComponentC,

        DefaultComponent,
        LoginComponent,
        RegistrationComponent,
        DashboardMainComponent,

        HomeComponent,
        AboutComponent,
        ContactComponent,
        ErrorComponent,
        MainComponent
        
    ], 
    providers:[SampleService, ProductService, CommunicationService, AppGuardService],
    bootstrap:[DashboardMainComponent]
})
export class AppModule{}

// 4. Making the AppModule as bootstrap
platformBrowserDynamic().bootstrapModule(AppModule);