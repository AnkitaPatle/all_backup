export class Employee {
  constructor(
    public EmpNo: number,
    public EmpName: string,
    public Salary: number,
    public DeptName: string,
    public Designation: string
  ) {}
  public Tax: number;
}

export const Departments: Array<string> =
        ['IT', 'HRD', 'System', 'Account'];
export const Designations: Array<string> =
        ['Lead', 'Manager', 'Engineer', 'Developer'];

export class EmployeeBizAction {
    employees: Array<Employee>;
    constructor() {
      this.employees = new Array<Employee>();
      this.employees.push(new Employee(101, 'Somya', 500000, 'IT', 'Developer'));
      this.employees.push(new Employee(101, 'Aryan', 800000, 'System', 'Manager'));
    }
    addEmployee(emp: Employee): Array<Employee> {
      this.employees.push(emp);
      return this.employees;
    }
}

