import React, { Component } from 'react';

class ProductComponent extends Component {
    constructor(props){
        super(props)
        this.state = {
            ProductID : 0,
            ProductName: "",
            CategoryName: "",
            Manufacturer: "",
            Price: 0,
            Products: [
                {ProductID: 101,
                ProductName: "Laptop",
                CategoryName: "Electronics",
                Manufacturer: "AB Tech",
                Price: 100000},

                {ProductID: 102,
                    ProductName: "Tab",
                    CategoryName: "Electronics",
                    Manufacturer: "AB Tech",
                    Price: 200000}
            ],
            Categories: ["Electronincs","Electricals","Food"],
            Manufacturers: ["AB Tech", "CB Power", "ABC Backer"]

        };
    }
    // e is an event-payload raised on target element
    // we can read the payload data using 'e'
    onChangeProductID(e){
        this.setState({ProductID: e.target.value});
    }

    onChangeProductName(e){
        this.setState({ProductName: e.target.value});
    }

    onChangeCategoryName(e){
        this.setState({CategoryName: e.target.value});
    }

    onChangeManufacturer(e){
        this.setState({Manufacturer: e.target.value});
    }

    onChangePrice(e){
        this.setState({Price: e.target.value});
    }

    OnClickClear(e){
        this.setState({ProductID: 0 });
        this.setState({ProductName: "" });
        this.setState({CategoryName: "" });
        this.setState({Manufacturer: "" });
        this.setState({Price: 0 });
    }

    OnClickSave(e){
        alert(`${this.state.ProductID} 
        ${this.state.ProductName} 
        ${this.state.CategoryName} 
        ${this.state.Manufacturer} 
        ${this.state.Price} `)

        // 1. get the copy of the Products array using slice()
        let tempArray = this.state.Products.slice();
        // 2. push the new record in to the tempArray
        tempArray.push({
            ProductID: this.state.ProductID,
            ProductName: this.state.ProductName,
            CategoryName: this.state.CategoryName,
            Manufacturer: this.state.Manufacturer,
            Price: this.state.Price
        });
        // 3. 
        this.setState({Products:tempArray});
    }

    getselectedProduct(p){

        this.setState({ProductID: p.ProductID });
        this.setState({ProductName: p.ProductName });
        this.setState({CategoryName: p.CategoryName });
        this.setState({Manufacturer: p.Manufacturer });
        this.setState({Price: p.Price });
    }

    
    render() { 
        return ( 
            <div className="container">
                <div className="form-group">
                    <label htmlFor="ProductID">ProductID</label>
                    <input type="text" className="form-control" 
                    value={this.state.ProductID} 
                    onChange={this.onChangeProductID.bind(this)} />
                </div>

                <div className="form-group">
                    <label htmlFor="ProductName">ProductName</label>
                    <input type="text" className="form-control"
                     value={this.state.ProductName}
                     onChange={this.onChangeProductName.bind(this)} />
                </div>

                <div className="form-group">
                    <label htmlFor="CategoryName">CategoryName</label>
                    <select className="form-control" value={this.state.CategoryName}
                    onChange={this.onChangeCategoryName.bind(this)}>
                    
                    { this.state.Categories.map((c,i) => (
                            <Options key={i} data ={c} />
                        ))
                    }

                    </select>
                </div>

                <div className="form-group">
                    <label htmlFor="Manufacturer">Manufacturer</label>
                    <select className="form-control" value={this.state.Manufacturer}
                    onChange={this.onChangeManufacturer.bind(this)}>

                    { this.state.Manufacturers.map((c, i) => (
                            <Options key={i} data ={c} />
                        ))
                    }
                    </select>
                </div>

                <div className="form-group">
                    <label htmlFor="Price">Price</label>
                    <input type="text" className="form-control" value={this.state.Price}
                    onChange={this.onChangePrice.bind(this)}/>
                </div>

                <div className="form-group">
                    <table>
                        <tbody>
                            <tr>
                                <td>
                                    <input type="button" value="New" className="btn btn-default" 
                                    onClick = {this.OnClickClear.bind(this)}/>
                                </td>
                                <td>
                                    <input type="button" value="Save" className="btn btn-default" 
                                    onClick={this.OnClickSave.bind(this)}/>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div className="container">
                <table className="table table-default">
                    <thead>
                        <tr>
                            <th>ProductID</th>
                            <th>ProductName</th>
                            <th>CategoryName</th>
                            <th>Menufacturer</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        { this.state.Products.map((prd, idx) => (
                                <TableRow 
                                key={idx} 
                                row={prd} 
                                selected={this.getselectedProduct.bind(this)}/>
                            ))}
                    </tbody>
                </table>
                </div>
            </div>            
         );
    }
}

//Component that will render <option></option>
// props.data is the data passed from the parent of this component
class Options extends Component {
    
    render() { 
        return ( 
            <option value={this.props.data}>{this.props.data}</option>
         );
    }
}

class TableRow extends Component{
    constructor(props){
        super(props);
    }

    onRowClick(){
        //alert(`Row Clicked ${JSON.stringify(this.props.row)}`);
        this.props.selected(this.props.row)
        
    }

    render(){
        return(
            <tr onClick={this.onRowClick.bind(this)}>
                <td>{this.props.row.ProductID}</td>
                <td>{this.props.row.ProductName}</td>
                <td>{this.props.row.CategoryName}</td>
                <td>{this.props.row.Manufacturer}</td>
                <td>{this.props.row.Price}</td>
            </tr>
        );
    }
}

 
export default ProductComponent;