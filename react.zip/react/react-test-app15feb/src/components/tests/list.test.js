import React from 'react';
import { shallow, mount } from "./../../enzyme";

import List from './../list';

describe("List tests", () => {
    //  test case
    it("should renders list-items", () => {
        // the test data
        const items = ["one", "two", "three"];

        //read the component mounting after rendering
        const wrapper = mount(<List items = {items} />);
        console.log(wrapper.debug());

        expect(wrapper.find(".list-items")).toBeDefined();
        expect(wrapper.find(".item")).toHaveLength(items.length);
    });
});