import React from 'react';
import { shallow, mount } from "./../../enzyme";

import ProductComponent from './../application/productComponent';

describe("Product test", () => {
    
})