The "React"
1. The React DOM for following
    1. The "Component" class
        1. The "constructor()" used to define state and behaviour for the component
        2. The "render()" method, used to control HTML DOM with data and behaviour
    2. Manages hierarchies of components with their lifecycle
        1. Manages Parent/Child rendering and data sharing relationship across components.
    3. The JSX --> babel-preset-es2015 and babel-preset-react libs
        1. React.CreateClass() and act.CreateElement() bjects for rendering

2. The React-Dom lib
    1. Uses JSX for rendering
        1. ues component om from "react" lib
        2. only one "export default" per JSX file

==========================================================================================================

React Components
1. Stateless Component
    - Component that have only DOm Encapsulation and no data(state and props) in it

2. Statefull Component
    - Has their OWN data
        - Defiend using "state" object inside constructor
        - The 'state' is always loacal component
        - The 'setState()' method of the component class to update the state of the component
            - setState({stateProps:value}, callback function to update in async mode);
            - Note: callback is mandatory in case of state changes for <select> element

    - Has data received from their "Parent" component
        - Defined using "props" parameter passed to constructor
        - The 'props' are always acress component

3. Statefull 'Controlled-Component'
    - Event and data binding for each editable elememt is used

4. Statefull 'UnControlled-Component'
    - State is not defined using "state" object but, the editable element has implicit object declaration

5. React.js Design Pattern React 16.x+
    - Higher-Order-Component (HoC)

======================================================================================================

window.fetch() --> es6
window.request() --> wrap over fetch
axios package for AJAX calls from react to REST

all of the above returns as "Promise" object

fethch("<URL>", "{OPTIONS}")
OPTIONS

method: GET/POST/PUT/DELETE --> GET is a default method
header: Carry request headers
body: Carry data over server

var promise = fetch(); --> service.js

component.js
    componentDidMount() method --> make sure the following
        1. all props are received for the component
        2. all state properties are manipulated
        3. call render() method
            - element + binding+ events
        4. componentDidMount() --> execute all async codes eg. REST calls subscription
            - to subscribe to promise
                -promise.then()  //received data
                        -.then() //to process data inside component
                        -.catch()//if error occures
                -promise.then().then().catch();
                        

