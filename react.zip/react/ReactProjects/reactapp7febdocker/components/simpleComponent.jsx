import React, { Component } from 'react';

class SimpleComponent extends Component {
    // The constructor will be used for state definition to accept data from parent component
    // The "props" represent data to received from the parent component
    constructor(props){
        super(props);
        // state declaration
        // event-binding to component
    }
    
    // The render() method encapsulate DOM and its data with behavior
    // This returns the DOM object aka Virtual DOM
    render() { 
        return (
            <div>
                
                <h2>The Simple Component!!!! {this.props.myname}</h2>
                <br />
                <NewComponent />
            </div>
        );
    }
}

class NewComponent extends Component {
    
    render() { 
        return (
            <div>
                <h2>The New Component </h2>
            </div>
          );
    }
}
  
export default SimpleComponent;