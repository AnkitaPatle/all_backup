

function operations(...values) {
    let sum =0;
    if(values.length > 0){
        for(let i = 0; i<values.length; i++){
        sum += values[i];
    }
}
    return sum;
}

console.log(operations(3,4));
console.log(operations(3,4,5));
console.log(operations(3,4,5,6));
