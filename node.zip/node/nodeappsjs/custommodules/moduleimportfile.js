var util = require("./utilitymodule");
var math = require("./wholemodule");

var http = require("http");
var fs = require("fs");

var str = "Node.js";
console.log(`case with upper for ${str} is ${util.caseutitily(str,"U")}`);
console.log(`case with Lower for ${str} is ${util.caseutitily(str,"L")}`);
console.log(`Reverse of  ${str} = ${util.reverse(str)}`);

var server = http.createServer(function(request,response){
    var file = "..";
    file 
});