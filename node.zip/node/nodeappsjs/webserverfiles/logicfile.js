var file = [
    {pg1:101, page1 : "./page1.html"},
    {pg2:102, page2 : "./page2.html"},
    {pg2:103,page3 : "./page3.html"},
    {pg4:104,page4 : "./page4.html"}
]

var server = http.createserver(function(request,responce){
 
});