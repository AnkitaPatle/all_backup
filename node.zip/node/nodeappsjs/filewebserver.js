var http = require("http");
var fs = require("fs");

// 1. create server object with listner
var server = http.createServer(function(request, response){
    // 2. parse the req. and read url
    if(request.url === "/home"){
        // 2a. read for home page
        fs.readFile("./home.html", function(err,data){
            if(err){
                response.writeHead(401,{"Content-Type":"text/html"})
                response.write("Resource is not available");
                response.end();
            }
                response.writeHead(200,{"Content-Type":"text/html"})
                response.write(data);
                response.end();
            
        });

    }else{
        if(request.url === "/about"){
            // 2b. read for about page
            fs.readFile("./about.html", function(err,data){
                if(err){
                    response.writeHead(401,{"Content-Type":"text/html"})
                    response.write("Resource is not available");
                    response.end();
                }
                    response.writeHead(200,{"Content-Type":"text/html"})
                    response.write(data);
                    response.end();
                
            });
        }
    }


});
server.listen(4060);
console.log("Server started on port 4060");
