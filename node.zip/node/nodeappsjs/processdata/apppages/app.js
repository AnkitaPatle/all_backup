var http = require("http");
var fs = require("fs");

var ProductPage = fs.readFileSync("./../apppages/myapp.html")

var server = http.createServer(function(request,response){
    if(request.method === "GET"){
        response.writeHead(400,{"Content-Type" : "text/html"});
        response.end(ProductPage);
    }
    if(request.method === "POST"){
        var ProductData = "";
        request.on("data", function(prd){
            ProductData += prd;
        }).on("end", function(){
            console.log("Received data is: " +ProductData.toString());
            response.end("Received data from you"+ProductData.toString());            
        });
    }
});
server.listen(5050);
console.log("Server Started on 5050");
