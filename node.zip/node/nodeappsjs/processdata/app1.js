var http = require('http');
 
var prod = [];
 
var extServerOptions = {
    host: "apiapptrainingservice.azurewebsites.net",
    path: "/api/Products",
    //port : 4050,
    method: "GET"
};
function get() {
    http.request(extServerOptions, function (response) {
        response.setEncoding('utf8');
        response.on('data', function (data) {
            prod = JSON.parse(data);
            console.log(prod);
            // prod.foreach(function (p) {
            //     console.log(p.BasePrice + "\t" + p.CategoryName + "\t" + p.Description + "\t" + p.Manufacturer + "\t" + p.ProductId + "\t" + p.ProductName + "\t" + p.ProductRowId);
            // });
        }).on('error', function (error) {
            console.error(error.message);
                
        });
 
    }).end();
}; 
get();
 
console.log("Doing the Post Operations....");

var Products = JSON.stringify({
    "BasePrice" : "12345",
    "CategoryName" : "Electronics",
    "Description" : "Mobile Phone",
    "Manufacturer" : "Apple",
    "ProductId" : 1056,
    "ProductName" : "IphoneX"
    
});
// console.log(Products);
  
var extServerOptionsPost = {
    host: "apiapptrainingservice.azurewebsites.net",
    path: "/api/Products",
    method: "POST",
    headers: {'Content-Type': 'application/json','Content-Length': Products.length}

};
//console.log(extServerOptionsPost);
 
var reqPost = http.request(extServerOptionsPost, function (res) {
    console.log("response statusCode: ", res.statusCode);
    res.on('data', function (data) {
        console.log('Posting Result:\n');
        process.stdout.write(data);
        console.log('\n\nPOST Operation Completed');
    }).on('error', function (error) {
        console.error(error.message);
            
    });
});
//console.log(reqPost);
 
reqPost.write(Products.toString());
reqPost.end();
reqPost.on('error', function (error) {
    console.error(error.message);
        
});
 
get();
console.log("Done");