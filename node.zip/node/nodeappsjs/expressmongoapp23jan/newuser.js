var express = require("express");
var path = require("path");

var instance = express();
var router = express.Router();
instance.use(router);

var bodyParser = require("body-parser");
instance.use(bodyParser.urlencoded({extended: false}));
instance.use(bodyParser.json());

var dbcon = require("./dbcon");

instance.post("/api/user", function(request, response){
    var user = request.body;
    userModel.create(user, function(err, res){
        if(err){
            response.statusCode = 500;
            response.send({status: response.statusCode, error:err});
        }
        response.send({status: 200, data:res});
     });        
});

instance.listen(4070,function(){
        console.log("Start listing on port 4070");        
    });