var dbcon = require("./dbcon");

module.exports = {
    authUser : function(username,password,cb){
    var UserId = username;
    var Password = password;

    userModel.findOne({UserId: UserId, Password:Password},function(err, res){
        if(err){
            // = false;
            console.log(err);
             // response.statusCode = 500;
            // response.send({status: response.statusCode, error:err});
        }
        else{
            if(res){
                 return cb(true);
                }else{
                    return cb(false);
                }
       //response = true;
        // if(!res){
        //    return response.status(404).send("Username or Password incorrect");
        // }
        //return response.status(200).send("Login Successfully");
        }
    });
}
}
