var arr;
arr = new Array();
arr.push("Ankita");
arr.push("Ram");
arr.push("Bharat");
arr.push("Rohini");
arr.push("Neha");
arr.push("Anamika");
arr.push("Bhushan");
arr.push("Ashwini");
//arr.sort((a1,a2) => a2.length - a1.length);
//console.log("Sorted by String length: "+JSON.stringify(arr));
arr.sort(function (a, b) {
    var nameA = a.toLowerCase(), nameB = b.toLowerCase();
    if (nameA < nameB) //sort string ascending
        return -1;
    if (nameA > nameB)
        return 1;
    return 0; //default return value (no sorting)
});
console.log("Sorted by alphabatic order: " + JSON.stringify(arr));
