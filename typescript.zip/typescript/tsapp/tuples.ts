// 1. simple tuple
// tuple contains first value as string and 2nd as number
let val:[string,number];
//rules for tuples
// 1. value type must be followed by tuple
// 2. tuple must be initialized
val = ["A", 101]; //initialization
console.log(`${val[0]} ${val[1]}`);

//define a tuple using "type" for complex data
// TupleData is type and [number,{}] is the type of TupleData
type TupleData = [number, {}];

let productRecord: TupleData;  //Defining a reference type of TupleData
// Initializing TupleData reference type
productRecord = [1, {ProductID:101,ProductName:"Laptop"}];
productRecord.push([2, {ProductID:102,ProductName:"Desktop"}]);
productRecord.push([3, {ProductID:103,ProductName:"Router"}]);

for(let p of productRecord){
    console.log(p);
}