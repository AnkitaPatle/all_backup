export class StringOperations{
    getLength(str:string):number{
        return str.length;
    }
    changeCase(str:string, formate:string):string{
        if(formate==="U"){
            return str.toUpperCase();
       }
       if(formate==="L"){
           return str.toLowerCase();
       }
       return str;
    }
}