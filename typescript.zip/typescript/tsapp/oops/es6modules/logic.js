"use strict";
exports.__esModule = true;
var StringOperations = /** @class */ (function () {
    function StringOperations() {
    }
    StringOperations.prototype.getLength = function (str) {
        return str.length;
    };
    StringOperations.prototype.changeCase = function (str, formate) {
        if (formate === "U") {
            return str.toUpperCase();
        }
        if (formate === "L") {
            return str.toLowerCase();
        }
        return str;
    };
    return StringOperations;
}());
exports.StringOperations = StringOperations;
