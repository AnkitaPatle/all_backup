
import{StringOperations} from "./logic";
let strOp = new StringOperations();
let str : string = "Harbinger Group";

console.log(`Length of ${str} = ${strOp.getLength(str)}`);
console.log(`Upper case of ${str} = ${strOp.changeCase(str, "U")}`);
console.log(`Lower case of ${str} = ${strOp.changeCase(str, "L")}`);

