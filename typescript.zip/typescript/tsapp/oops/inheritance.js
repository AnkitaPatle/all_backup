var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Product = /** @class */ (function () {
    function Product(ProdID, ProdName) {
        this.ProdID = ProdID;
        this.ProdName = ProdName;
    }
    return Product;
}());
var ProductLogic = /** @class */ (function () {
    function ProductLogic() {
        this.product = new Product(0, "");
        this.products = new Array();
        this.products.push(new Product(101, "P1"));
        this.products.push(new Product(102, "P2"));
    }
    ProductLogic.prototype.getProduct = function () {
        return this.products;
    };
    ProductLogic.prototype.saveProduct = function (p) {
        this.products.push(p);
        return this.products;
    };
    return ProductLogic;
}());
var ProductOperation = /** @class */ (function (_super) {
    __extends(ProductOperation, _super);
    function ProductOperation() {
        return _super.call(this) || this;
    }
    ProductOperation.prototype.getProductByID = function (id) {
        //logic goes here
        return new Product(0, "");
    };
    ProductOperation.prototype.getProductsByCategory = function (cat) {
        //logic goes here
        return this.products;
    };
    return ProductOperation;
}(ProductLogic));
var Presenter = /** @class */ (function () {
    function Presenter() {
    }
    Presenter.prototype.generateTable = function () {
        var Products = [
            { ProdID: 101, ProdName: "P1" },
            { ProdID: 102, ProdName: "P2" },
        ];
        var table = "<table><tr><td>ProdId</td><td>ProdName</td>";
        for (var _i = 0, Products_1 = Products; _i < Products_1.length; _i++) {
            var p = Products_1[_i];
            table += "<tr><td> " + p.ProdID + "</td> <td>" + p.ProdName + "</td>";
        }
        table += "</table>";
        return table;
    };
    return Presenter;
}());
var prdOperation = new ProductOperation();
console.log(JSON.stringify(prdOperation.getProduct()));
var prd = new Product(103, "P3");
console.log();
console.log(JSON.stringify(prdOperation.saveProduct(prd)));
