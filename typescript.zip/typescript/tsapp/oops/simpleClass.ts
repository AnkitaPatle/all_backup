class MathClass {

  //  private x:number = 0;
  //  private y:number = 0;
    private z:number = 0;

    constructor(private x:number,private y:number){
    
        //this.x = x;
        //this.y = y;
    }
    add():number{
        this.z = this.x +this.y;
        return this.z;

    }
    sub():number{
        this.z = this.x - this.y;
        return this.z;

    }
}

let mObj = new MathClass(20,40);
console.log(`add = ${mObj.add()}`);
console.log(`add = ${mObj.add()}`);
