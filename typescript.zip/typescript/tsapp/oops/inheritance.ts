class Product{
    constructor(
        public ProdID:number, public ProdName: string){}
}
class ProductLogic {
    product:Product;
    products:Array<Product>;
    constructor(){
        this.product = new Product(0,"");
        this.products = new Array<Product>();
        this.products.push(new Product(101,"P1"));
        this.products.push(new Product(102,"P2"));
    }
    getProduct(): Array<Product>{
        return this.products;
    }
    saveProduct(p: Product): Array<Product>{
        this.products.push(p);
        return this.products;
    }
}
class ProductOperation extends ProductLogic{
    constructor(){
        super();
    }
    getProductByID(id:number):Product{
        //logic goes here
        return new Product(0, "");
    }
    getProductsByCategory(cat:string):Array<Product>{
        //logic goes here
        return this.products;
    }
}

class Presenter{
    generateTable():string{
        let Products = [
            {ProdID:101, ProdName:"P1"},
            {ProdID:102, ProdName:"P2"},
        ];

        let table = "<table><tr><td>ProdId</td><td>ProdName</td>";
        for(let p of Products){
            table += `<tr><td> ${p.ProdID}</td> <td>${p.ProdName}</td>`;

        }
        table +="</table>"
        return table;
    }
}

let prdOperation = new ProductOperation();
console.log(JSON.stringify(prdOperation.getProduct()));
let prd = new Product(103,"P3");
console.log();
console.log(JSON.stringify(prdOperation.saveProduct(prd)));

