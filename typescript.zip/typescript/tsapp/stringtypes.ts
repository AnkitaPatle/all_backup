//variable names must start from lower case
//use camel-case for multiword variable name
let firstName: string = "Ankita";
let middleName: string = "Shobha";
let lastName: string = "Hema";

// 1. concatinate using old JS style(ES 3 to 5)
let fullNameOld = firstName+ " " + middleName+ " "+lastName;
console.log("Full name with old style "+fullNameOld);

let fullNameWithTempletString = `${firstName} ${middleName} ${lastName}`;
console.log(`with Templet String     
                    ${fullNameWithTempletString}`);