let mynames: Array<string>;
mynames = new Array<string>();

mynames.push("Adcgdscv jjcc");
mynames.push("Bbchdc ssd");
mynames.push("Chhdsdcsd ddasxasc");
mynames.push("Dsasgg");

 /* //Simple array Iteration
mynames.forEach(printValues);

function printValues(val:string, idx:number){
    console.log(`Data at ${idx} is ${val}`);
}

//Anonymous callback function
mynames.forEach(function(val:String,idx:number){
    console.log(`Data at ${idx} is ${val}`);
});

//ES 6 Array function
console.log();
console.log("User Array Operator");
mynames.forEach((val:String,idx:number) => {
    console.log(`Data at ${idx} is ${val}`);
});
 */ 

//Array method of ES6
//filter(), reduce(), map()
mynames.map((v:string,i:number) =>{
    console.log(`Data at ${i} is ${v}`);
});
let newArray = new Array<string>();
//returning all string having 
newArray = mynames.filter((val:string,idx:number) =>{
    return val.length > 12
});
newArray.forEach((val:string,idx:number)=>{
    console.log(val);
});






